# Project Report: Bean Leaf Disease Detection Using Transfer Learning

## 1. Project Title
Bean Leaf Disease Detection Using Deep Learning and Transfer Learning

## 2. Problem Statement
Farmers may find it difficult to identify common bean-leaf diseases from visual inspection. This project develops an image-classification application that predicts whether a bean leaf is healthy or belongs to one of two disease classes: Angular Leaf Spot or Bean Rust.

## 3. Dataset Source and Description
Dataset: Beans (Hugging Face Datasets: `beans`).
The dataset contains images in three classes: Angular Leaf Spot, Bean Rust, and Healthy. It provides training, validation, and test splits. Dataset source: https://huggingface.co/datasets/beans

## 4. Pretrained Model
Base model: `google/vit-base-patch16-224` (Vision Transformer).
Model page: https://huggingface.co/google/vit-base-patch16-224
The pretrained classification model is adapted to three output classes and fine-tuned on the bean-leaf dataset.

## 5. Data Preparation
Describe the dataset loading, label inspection, image resizing/normalization performed by the model processor, and the training/validation/test split. Add screenshots from the executed notebook.

## 6. Model Fine-Tuning
Describe the training settings used in the notebook, such as number of epochs, batch size, learning rate, and GPU/CPU runtime. Add the actual training output.

## 7. Evaluation
Insert the actual test accuracy and any other metrics printed by the notebook. Do not invent results.

Test accuracy: [ADD ACTUAL RESULT]
Other observations: [ADD ACTUAL RESULT]

## 8. Hugging Face Model Repository
Link: [PASTE YOUR MODEL REPOSITORY URL]
Explain that the fine-tuned model and image processor were uploaded and tested.

## 9. GitHub Repository
Link: [PASTE YOUR GITHUB REPOSITORY URL]
List the files included in the repository.

## 10. Streamlit Application and Deployment
Live application: [PASTE YOUR STREAMLIT URL]
Explain how a user uploads a bean-leaf image and receives a predicted class and confidence score. Add a screenshot.

## 11. Conclusion
This project demonstrates an end-to-end deep-learning workflow using transfer learning. A pretrained Vision Transformer is fine-tuned on a three-class bean-leaf image dataset. The trained model is hosted on Hugging Face, the source code is maintained on GitHub, and a Streamlit interface makes the model accessible through a web application. The project provides practical experience in dataset preparation, model fine-tuning, evaluation, model hosting, version control, application development, and cloud deployment. The model is an educational prototype and its predictions should be confirmed by an agricultural expert before making crop-management decisions.
