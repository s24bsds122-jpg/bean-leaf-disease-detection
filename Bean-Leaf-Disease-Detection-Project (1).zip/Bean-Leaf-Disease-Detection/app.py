import os
import streamlit as st
import torch
from PIL import Image
from transformers import AutoImageProcessor, AutoModelForImageClassification

st.set_page_config(page_title="Bean Leaf Disease Detection", page_icon="🌿", layout="centered")

st.title("🌿 Bean Leaf Disease Detection")
st.write(
    "Upload a clear photo of a bean leaf. The fine-tuned Vision Transformer model "
    "will predict whether it is healthy or shows one of the two diseases."
)

MODEL_ID = os.getenv("HF_MODEL_ID", "YOUR_HUGGINGFACE_USERNAME/bean-leaf-disease-vit")

@st.cache_resource
def load_model(model_id):
    processor = AutoImageProcessor.from_pretrained(model_id)
    model = AutoModelForImageClassification.from_pretrained(model_id)
    model.eval()
    return processor, model

uploaded = st.file_uploader("Choose a bean leaf image", type=["jpg", "jpeg", "png"])

if uploaded:
    image = Image.open(uploaded).convert("RGB")
    st.image(image, caption="Uploaded leaf image", use_container_width=True)

    if MODEL_ID.startswith("YOUR_HUGGINGFACE_USERNAME"):
        st.error("Set HF_MODEL_ID to your own Hugging Face model repository in Streamlit secrets or app settings.")
    else:
        try:
            with st.spinner("Analyzing the leaf..."):
                processor, model = load_model(MODEL_ID)
                inputs = processor(images=image, return_tensors="pt")
                with torch.no_grad():
                    logits = model(**inputs).logits
                    probabilities = torch.softmax(logits, dim=-1)[0]
                best_idx = int(torch.argmax(probabilities))
                label = model.config.id2label.get(best_idx, str(best_idx))
                confidence = float(probabilities[best_idx]) * 100

            st.subheader(f"Prediction: {label}")
            st.metric("Model confidence", f"{confidence:.1f}%")
            st.caption(
                "This is an educational AI prediction, not a professional agricultural diagnosis. "
                "For important crop decisions, confirm with an agriculture expert."
            )
            st.write("Class probabilities")
            scores = {
                model.config.id2label.get(i, str(i)): float(probabilities[i]) * 100
                for i in range(len(probabilities))
            }
            st.bar_chart(scores)
        except Exception as e:
            st.error(f"Could not load or run the model: {e}")
            st.info("Check that the Hugging Face repository exists and contains the model and image processor files.")
else:
    st.info("Upload an image to get a prediction.")
