# Bean Leaf Disease Detection Using Transfer Learning

A deep-learning image-classification project that fine-tunes a pretrained Vision Transformer (ViT) on the Beans leaf dataset.

## Classes
The dataset contains three labels:
- Angular Leaf Spot
- Bean Rust
- Healthy

## Model
- Pretrained model: `google/vit-base-patch16-224`
- Fine-tuning dataset: Hugging Face `beans` dataset
- Framework: PyTorch + Hugging Face Transformers

## Run the app locally

1. Create and activate a Python environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Set the model repository ID:

```bash
# Windows PowerShell
$env:HF_MODEL_ID="YOUR_USERNAME/bean-leaf-disease-vit"

# macOS/Linux
export HF_MODEL_ID="YOUR_USERNAME/bean-leaf-disease-vit"
```

4. Run:

```bash
streamlit run app.py
```

## Training

Open `notebooks/bean_leaf_transfer_learning.ipynb` in Google Colab.
Run cells from top to bottom. A GPU runtime is recommended.

When asked, enter your Hugging Face username and a write token in Colab's secure input.
Do not commit tokens or passwords to GitHub.

## Deployment

1. Push this repository to your own GitHub account.
2. Open Streamlit Community Cloud and deploy `app.py`.
3. In the app's Settings → Secrets, add:

```toml
HF_MODEL_ID = "YOUR_USERNAME/bean-leaf-disease-vit"
```

4. Redeploy and test with sample leaf images.

## Important
The model must be trained and uploaded by the student. Do not claim an accuracy score until the notebook has produced the test results. Predictions are educational and should not replace expert agricultural advice.
